import { useKeyword } from '@/app/(explorer)/_hooks/useKeyword';
import React from 'react';

interface Category {
  title: string;
  items: { name: string; count: number }[];
}

interface CategoriesContentProps {
  selectedResult: any;
}

const CategoriesContent: React.FC<CategoriesContentProps> = ({selectedResult}) => {
  
  const { suggestedSearch } = useKeyword();
  const categories = suggestedSearch[selectedResult?.id as string]

  if(!categories) return null;
  return (
    <div className='overflow-y-auto'>
      {
        categories.map((category:any, index: number) => (
          <div className="flex flex-col gap-2 p-2" key={index}>
            <span className="text-base p-2 font-medium text-slate-400">{category.title}</span>
            <ul>
              {category.items.map((item:any,index:number) => (
                <li key={index} className="py-1 px-2 flex justify-between gap-2">
                  <button type="button" className="w-full h-fit flex items-start text-[20px] text-slate-100 font-medium hover:text-slate-300 active:text-slate-400 transition-colors">
                    {item}
                  </button>
                  {/* <span className="text-slate-300 text-base">{item.count}</span> */}
                </li>
              ))}
            </ul>
          </div>
        ))
      }
    </div>
  );
}

export default CategoriesContent;
