import React, { useEffect } from 'react';
import SearchContent from './search-content';
import { useKeyword } from '@/app/(explorer)/_hooks/useKeyword';
import { categoriesData } from '@/components/mockdata';
import CategoriesContent from './categories-content';
import { NavigatorMenuInitialContent } from './Initial-content';

type NavigatorMenuPreviewProps = {
  searchResults?: any;
};

export const NavigatorMenuPreview: React.FC<NavigatorMenuPreviewProps> = () => {
  
  const { selectedResult, suggestedSearch } = useKeyword();
  // Log when selectedResult changes
  if(selectedResult && selectedResult.blockType){
    console.log(selectedResult)
    return(
      <CategoriesContent selectedResult={selectedResult} />
    )
  }else if ( selectedResult && !selectedResult.blockType ) {
    return (
      <SearchContent selectedResult={selectedResult} />
    )
  } else {
    return (
      <div>Initial Content</div>
      // <NavigatorMenuInitialContent />
    )
  }
}
